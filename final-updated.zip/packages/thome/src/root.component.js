import React from "react";
export default function Root(props) {
  const { appsStateObservable, appState, updateAppState } = props;
  const [mergedState, setMergedState] = React.useState({});
  appsStateObservable.subscribe({
    next: (message) => {
      setMergedState({ ...message });
      //check user details
    },
    error: (err) => {},
    complete: () => {},
  });

  let userdetails = sessionStorage.getItem("userdetails");
  const { thome } = mergedState;
  if (
    mergedState.route != "login" &&
    userdetails &&
    JSON.parse(userdetails)?.hasAccess?.indexOf("thome") > -1
  ) {
    if (thome.route === "thometest" || JSON.parse(userdetails)?.hasAccess.length === 1) { //react-router .. right now we are using html5 history
      return (
        <>
          <section style={{
            width: '200px',
            height: '200px',
            marginTop: '20%',
            marginLeft: '50%',
            backgroundColor: 'lightcoral', // Use the correct color name or hex code for light red
            border: '1px solid #ccc',
            boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
            padding: '20px',
            textAlign: 'center',
          }}>
            <div>
              <h1>Teacher Component Loaded</h1>
            </div>
          </section>
        </>
      );     
    }    
   else {
        return <></>;
      }  
    }
   else {
    return <></>;
  }
}
