import React from "react";

const Login = ({updateAppState}) => {
  const [username, setUserName] = React.useState();
  const [password, setPassword] = React.useState();
  const [errorMessage, setErrorMessage] = React.useState("");
  return (
    <><section style={{
      position: 'absolute',
      top: '20%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      zoom: '150%'
    }}>
      <div className="contaner" style={{ display: 'flex', justifyContent: 'center' }}>
      <div style={{ display: 'flex', flexDirection: "column", gap: "15px" }}>      
      
        <label for="uname">
          Username
        </label>
        <input
          type="text"          
          name="uname"
          required
          value={username}
          onChange={(event) => {
            setUserName(event.target.value)
          }}
        />
        <label for="psw">
          Password
        </label>
        <input
          type="password"          
          name="psw"
          value={password}
          required
          onChange={(event) => {
            setPassword(event.target.value)
          }}
        />

        <button type="submit" onClick={() => {
          setErrorMessage("");
          if(username === "sdemo") {
            sessionStorage.setItem("userdetails", JSON.stringify({
              username: username,
              hasAccess: ["shome"]
            }));
            updateAppState({route: "home"});
            history.pushState({}, "", "home");
          } else if(username === "tdemo") {
            sessionStorage.setItem("userdetails", JSON.stringify({
              username: username,
              hasAccess: ["thome"]
            }))
            updateAppState({route: "home"});
            history.pushState({}, "", "home");
          } else if(username === "admin") {
            sessionStorage.setItem("userdetails", JSON.stringify({
              username: username,
              hasAccess: ["home","thome", "shome"]
            }))
            updateAppState({route: "home"});
            history.pushState({}, "", "home");
          }
          setErrorMessage("Invalid credentials")
        }}>
          Login
        </button>
      </div>
      </div>
      <div><br></br>{errorMessage}</div>
      </section>
    </>
  );
};

export default Login;
