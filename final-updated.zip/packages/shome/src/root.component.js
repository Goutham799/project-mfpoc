import React from "react";
export default function Root(props) {
  const { appsStateObservable, appState, updateAppState } = props;
  const [mergedState, setMergedState] = React.useState({});

  appsStateObservable.subscribe({
    next: (message) => {
      setMergedState({ ...message });
      //check user details
    },
    error: (err) => {},
    complete: () => {},
  });

  let userdetails = sessionStorage.getItem("userdetails");
  const { shome } = mergedState;
  if (
    mergedState.route != "login" &&
    userdetails &&
    JSON.parse(userdetails)?.hasAccess?.indexOf("shome") > -1
  ) {
    if (shome.route === "shometest" || JSON.parse(userdetails)?.hasAccess.length === 1) { //react-router .. right now we are using html5 history
      return (
        <>
          <section style={{
            width: '200px',
            height: '200px',
            backgroundColor: 'lightblue', // Use the correct color name or hex code for light red
            border: '1px solid #ccc',
            boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
            padding: '20px',
            textAlign: 'center',
            marginTop: '20%',
            marginLeft: '30%',
          }}>
            <div>
              <h1>Student Component Loaded</h1>
            </div>
          </section>
        </>
      );     
    }    
   else {
        return <></>;
      }  
  } else {
    return <></>;
  }
}