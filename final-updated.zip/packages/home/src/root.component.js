import React from "react";
export default function Root(props) {
  const { appsStateObservable, appState, updateAppState } = props;
  const [mergedState, setMergedState] = React.useState({});
  const [loggedIn, setLoggedIn] = React.useState(false);
  const [loggedInUser, setLoggedInUser] = React.useState();
  appsStateObservable.subscribe({
    next: (message) => {
      setMergedState({ ...message });
    },
    error: (err) => {},
    complete: () => {},
  });

  const checkUserDetails = () => {
    let userdetails = sessionStorage.getItem("userdetails");
    if (!userdetails) {
      setTimeout(() => {
        updateAppState({ ...mergedState, route: "login" });
      }, 200);
      history.pushState({}, "", "login");
    } else {
      setLoggedIn(true);
      const userObject = JSON.parse(userdetails);
      setLoggedInUser(userObject);
    }
  };

  const logout = () => {
    sessionStorage.clear();
    setLoggedIn(false);
    setLoggedInUser(undefined);
    updateAppState({
      login: {},
      home: {},
      shome: {},
      thome: {},
      route: "login"
    });
    checkUserDetails();
  };

  const loadTestComponentSHome = () => {
    const sHome = {
      shome: {
        route: "shometest",
      },
    };
    const tHome = {
      thome: {
      },
    };
    const tempMergedState = {
      ...mergedState,
      ...sHome,
      ...tHome
    };
    updateAppState(tempMergedState);
  };

  const loadTestComponentInTHome = () => {
    const tHome = {
      thome: {
        route: "thometest",
      },
    };

    const sHome = {
      shome: {
      },
    };
    const tempMergedState = {
      ...mergedState,
      ...tHome,
      ...sHome
    };
    updateAppState(tempMergedState);
  };

  console.log("props in home-----", mergedState)
  React.useEffect(() => {
    checkUserDetails();
  }, [mergedState.route]);
  if (loggedIn) {
    return (
      <><section style={{
        position: 'absolute',
        top: '20%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        zoom: '150%'
      }}>
        <div>
          Welcome {loggedInUser?.username === "sdemo" && (<>Student</>)}
          {loggedInUser?.username === "tdemo" && (<>Teacher</>)}
          {loggedInUser?.username === "admin" && (<>Admin</>)}
        </div>
        {loggedInUser?.username === "admin" && (
          <div>
            <br></br>
            <button onClick={loadTestComponentSHome}>
              Load Student Component
            </button> &ensp;
            <button onClick={loadTestComponentInTHome}>
              Load Teacher Component
            </button>            
          </div>
        )}
        <div>
          <br></br>
          <button onClick={logout}>Logout</button>
        </div>
        </section>
      </>
    );
  } else {
    return <></>;
  }
}
