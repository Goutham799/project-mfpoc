const express = require('express');
const spauth = require('node-sp-auth');
const fs = require('fs');
const Jimp = require('jimp');
const app = express();
const cors = require('cors');
const port = 3000; 
const fetch = require('node-fetch'); 
const csvParser = require('csv-parser');

app.use(cors()); 
app.use(express.json()); 

const spAuthConfig = {
    username: 'mreddimasu@guardianfueltech.com',
    password:'Greenolive@12345',
    online: true //setting this to true for SharePoint Online
}


// Function to send emails
// Parse the CSV into a JSON array
function parseCsv(filePath) {
    return new Promise((resolve, reject) => {
      const results = [];
      fs.createReadStream(filePath)
        .pipe(csvParser())
        .on('data', (data) => results.push(data))
        .on('end', () => resolve(results))
        .on('error', (error) => reject(error));
    });
  }
  
  // Endpoint to search employees by name
  app.get('/api/employees/search', async (req, res) => {
    const { term } = req.query;
    try {
      const employees = await parseCsv('C:\\Users\\MoulishaReddimasu\\Documents\\ecard_emp.csv');
      const matches = employees.filter(emp =>
        emp.name.toLowerCase().includes(term.toLowerCase())
      );
      res.json(matches);
    } catch (error) {
      console.error('Error searching employees:', error);
      res.status(500).send('Error searching for employees');
    }
  });
  
//function to get image from sharepoint

async function getImageFromSharePoint(url) {
    const response = await spauth.getAuth(url, spAuthConfig);
    const headers = response.headers;
    headers['Accept'] = 'application/json;odata=verbose';
  
    const imageResponse = await fetch(url, { headers: headers });
    return imageResponse.buffer(); // Get the image as a buffer
  }



async function overlayTextOnImage(imagePath, text) {
    try {
        const imageBuffer = await getImageFromSharePoint(imagePath);
        const image = await Jimp.read(imageBuffer);    
        const font = await Jimp.loadFont(Jimp.FONT_SANS_32_BLACK);
        const textWidth = Jimp.measureText(font, text);
        const textHeight = Jimp.measureTextHeight(font, text, image.bitmap.width);

        const x = (image.bitmap.width - textWidth) / 2; // Center the text horizontally
        const y = (image.bitmap.height - textHeight) / 2; // Center the text vertically

        image.print(font, x, y, text);
        
        const outputFilename = 'output-' + Date.now() + '.png';
        await image.writeAsync(outputFilename);

        return outputFilename;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Endpoint to receive form data and process e-card
app.post('/api/sendEcard', async (req, res) => {
    const { from, to, message, template } = req.body;
    console.log('Received request to send E-card:', req.body);
    try {
        const outputFilename = await overlayTextOnImage(template, message);
        console.log('E-card Image Created:', outputFilename);
        console.log('Awaiting to send an email...')
        await sendEmail({
            from: from,
            to: to,
            subject: "You've received an E-Card!",
            text: message,
            attachment: outputFilename
        });
        console.log('Email sent successfully');
        res.status(200).send({ message: 'E-card sent successfully' });
    } catch (error) {
        console.error('Failed to send e-card:', error.message);
        res.status(500).send({ message: 'Error in creating or sending e-card', error: error.message });
    }
});


app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});

