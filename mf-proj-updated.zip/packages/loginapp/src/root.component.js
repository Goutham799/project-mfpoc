import React from "react";

import Login from "./components/Login";

export default function Root(props) {
  const { appsStateObservable, appState, updateAppState } = props;
  const [mergedState, setMergedState] = React.useState();
  const { route } = mergedState ? mergedState : {};
  appsStateObservable.subscribe({
    next: (message) => {
      setMergedState(message);
    },
    error: (err) => {},
    complete: () => {},
  });

  const updateStateInternal = (keyValue) => {
    updateAppState({ ...mergedState, ...keyValue });
  };

  if (route === "login") {
    return <Login updateAppState={updateStateInternal} />;
  }
  {
    return <></>;
  }
}
