import { registerApplication, start, getMountedApps } from "single-spa";
import {
  constructApplications,
  constructRoutes,
  constructLayoutEngine,
} from "single-spa-layout";
import microfrontendLayout from "./microfrontend-layout.html";

/**
 * observables
 */
import { Subject } from "rxjs";
sessionStorage.clear();
const communicationObservable = new Subject();
/**
 * we can use here redux store, this simple js object has been to reduce the complexity
 */
let appState = {
  login: {},
  home: {},
  shome: {},
  thome:{}
};
let customProps = {};

async function updateAppState(keyValue) {
  communicationObservable.next({...appState, ...keyValue});
}


customProps = {
  document: document, //this has no real as of now.. need this for styling
  appState: appState,
  updateAppState: updateAppState, // in case of redux these will be reducers
  appsStateObservable: communicationObservable //communication link rx js subject
};

const routes = constructRoutes(microfrontendLayout);
const applications = constructApplications({
  routes,
  loadApp({ name }) {
    return System.import(name);
  },
});
const layoutEngine = constructLayoutEngine({ routes, applications });

applications.forEach((app) =>
  registerApplication({
    name: app.name,
    app: app.app(),
    activeWhen: (location) => true,
    customProps,
  })
);
layoutEngine.activate();
start();
