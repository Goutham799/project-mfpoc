import React from "react";
export default function Root(props) {
  const { appsStateObservable, appState, updateAppState } = props;
  const [mergedState, setMergedState] = React.useState({});
  appsStateObservable.subscribe({
    next: (message) => {
      setMergedState({ ...message });
      //check user details
    },
    error: (err) => {},
    complete: () => {},
  });

  let userdetails = sessionStorage.getItem("userdetails");
  const { thome } = mergedState;
  if (
    mergedState.route != "login" &&
    userdetails &&
    JSON.parse(userdetails)?.hasAccess?.indexOf("thome") > -1
  ) {
    if (thome.route === "thometest") {
      return <> {thome.route} component loaded</>;
    } else {
      return <>shome</>;
    }
  } else {
    return <></>;
  }
}
