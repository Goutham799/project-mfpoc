import React from "react";
export default function Root(props) {
  const { appsStateObservable, appState, updateAppState } = props;
  const [mergedState, setMergedState] = React.useState({});

  appsStateObservable.subscribe({
    next: (message) => {
      setMergedState({ ...message });
      //check user details
    },
    error: (err) => {},
    complete: () => {},
  });

  let userdetails = sessionStorage.getItem("userdetails");
  const { shome } = mergedState;
  if (
    mergedState.route != "login" &&
    userdetails &&
    JSON.parse(userdetails)?.hasAccess?.indexOf("shome") > -1
  ) {
    if (shome.route === "shometest") {
      return <> {shome.route} component loaded</>;
    } else {
      return <>shome</>;
    }
  } else {
    return <></>;
  }
}
