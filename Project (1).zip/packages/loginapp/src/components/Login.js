import React from "react";

const Login = ({updateAppState}) => {
  const [username, setUserName] = React.useState();
  const [password, setPassword] = React.useState();
  const [errorMessage, setErrorMessage] = React.useState("");
  return (
    <>
      <div className="container">
        <label for="uname">
          <b>Username</b>
        </label>
        <input
          type="text"
          placeholder="Enter Username"
          name="uname"
          required
          value={username}
          onChange={(event) => {
            setUserName(event.target.value)
          }}
        />

        <label for="psw">
          <b>Password</b>
        </label>
        <input
          type="password"
          placeholder="Enter Password"
          name="psw"
          value={password}
          required
          onChange={(event) => {
            setPassword(event.target.value)
          }}
        />

        <button type="submit" onClick={() => {
          setErrorMessage("");
          if(username === "sdemo") {
            sessionStorage.setItem("userdetails", JSON.stringify({
              username: username,
              hasAccess: ["shome"]
            }));
            updateAppState({route: "home"});
            history.pushState({}, "", "home");
          } else if(username === "tdemo") {
            sessionStorage.setItem("userdetails", JSON.stringify({
              username: username,
              hasAccess: ["thome"]
            }))
            updateAppState({route: "home"});
            history.pushState({}, "", "home");
          } else if(username === "admin") {
            sessionStorage.setItem("userdetails", JSON.stringify({
              username: username,
              hasAccess: ["home","thome", "shome"]
            }))
            updateAppState({route: "home"});
            history.pushState({}, "", "home");
          }
          setErrorMessage("username is not valid, use tdemo, sdemo, admin")
        }}>
          Login
        </button>
      </div>
      <div>{errorMessage}</div>
    </>
  );
};

export default Login;
